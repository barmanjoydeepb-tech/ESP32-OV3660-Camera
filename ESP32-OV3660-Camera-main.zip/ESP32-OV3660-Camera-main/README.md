# ESP32-CAM (OV3660) Video Streamer

This project implements a Wi-Fi Video Streaming Web Server using the ESP32-CAM module and the upgraded OV3660 (3MP) sensor.

## Hardware Used
* **MCU:** ESP32-S (AI Thinker Form Factor)
* **Sensor:** OV3660 (3 Megapixel, Higher quality than standard OV2640)
* **Interface:** ESP32-CAM-MB (Micro USB Shield with CH340 serial chip)

## Features
* Real-time MJPEG Streaming
* OV3660 Sensor Correction (Fixes Blue/Inverted colors)
* Web Interface for control (Resolution, LED, etc.)
* Resolution set to UXGA (1600x1200)

## Installation Guide (Linux)

### 1. Arduino IDE Setup
* **Board Manager:** Install `esp32` by Espressif Systems.
* **Version Note:** Use version **2.0.17**. (Version 3.0.x causes `ledcAttach` errors).
* **Board Selection:** Select `AI Thinker ESP32-CAM`.

### 2. Configuration
1.  Open `CameraWebServer.ino`.
2.  Enter your Wi-Fi credentials in `ssid` and `password`.
3.  In `camera_pins.h`, ensure you uncomment:
    ```cpp
    #define CAMERA_MODEL_AI_THINKER
    ```
    (Disable `CAMERA_MODEL_ESP_EYE` if it is enabled by default).

### 3. Flashing
* Connect the board via USB.
* Select Port `/dev/ttyUSB0`.
* Upload code.
* **Note:** If upload hangs, press the RST button on the board.

## Usage
1.  Open Serial Monitor at **115200 baud**.
2.  Press the RST button on the board.
3.  Copy the IP address displayed (e.g., `http://192.168.1.X`).
4.  Open the IP in a browser and click **"Start Stream"**.
